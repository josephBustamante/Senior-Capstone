//
//  ToursTablesVC.h
//  Tour Buddy
//
//  Created by Joseph Bustamante on 4/23/13.
//  Copyright (c) 2013 Joseph Bustamante. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef NS_ENUM(NSInteger,tourOption)
{
    Athletic = 0,
    Scholastic,
    General,
    Dorm,
    ComputerSci
    
};

@interface ToursTablesVC : UITableViewController



@end
