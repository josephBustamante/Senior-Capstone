//
//  AppDelegate.h
//  Tour Buddy
//
//  Created by Joseph Bustamante on 4/23/13.
//  Copyright (c) 2013 ___FULLUSERNAME___. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
